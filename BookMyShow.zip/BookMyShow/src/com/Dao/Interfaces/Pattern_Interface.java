package com.Dao.Interfaces;

import java.sql.SQLException;

public interface Pattern_Interface {

	void hall() throws ClassNotFoundException, SQLException;
}
