package com.Dao.Interfaces;

import java.sql.SQLException;

public interface Show_Movies_Interface {

	void show(String ulocc) throws ClassNotFoundException, SQLException; 
}
