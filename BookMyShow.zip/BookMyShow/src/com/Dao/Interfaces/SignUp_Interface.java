package com.Dao.Interfaces;

import java.sql.SQLException;

public interface SignUp_Interface {

	void signup() throws SQLException, ClassNotFoundException;
}
