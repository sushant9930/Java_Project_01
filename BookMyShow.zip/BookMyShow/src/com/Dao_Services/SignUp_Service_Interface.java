package com.Dao_Services;

import java.sql.SQLException;

import com.Dao.SignUp;

public interface SignUp_Service_Interface
{
	void signup() throws SQLException, ClassNotFoundException;
}
