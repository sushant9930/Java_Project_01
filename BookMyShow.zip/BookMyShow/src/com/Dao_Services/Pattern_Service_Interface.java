package com.Dao_Services;

import java.sql.SQLException;

import com.Dao.Pattern;

public interface Pattern_Service_Interface
{
	void hall() throws ClassNotFoundException, SQLException;
}
